﻿@echo off
chcp 65001 >nul 2>&1
echo ============================================
echo   text2img-mcp ?ㅼ튂 ?ㅽ겕由쏀듃
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [?ㅻ쪟] Python???ㅼ튂?섏뼱 ?덉? ?딆뒿?덈떎.
    echo Python 3.10 ?댁긽???ㅼ튂?댁＜?몄슂: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/3] 媛?곹솚寃??앹꽦 以?..
if not exist ".venv" (
    python -m venv .venv
)

echo [2/3] ?섏〈???ㅼ튂 以?..
call .venv\Scripts\activate.bat
pip install -r requirements.txt

echo [3/3] ?ㅼ튂 ?꾨즺!
echo.
echo ============================================
echo   Claude Desktop ?ㅼ젙 諛⑸쾿
echo ============================================
echo.
echo 1. Claude Desktop ?ㅼ젙 ?뚯씪???댁뼱二쇱꽭??
echo    %%APPDATA%%\Claude\claude_desktop_config.json
echo.
echo 2. ?꾨옒 ?댁슜??mcpServers??異붽??섏꽭??
echo.
echo    "text2img-mcp": {
echo      "command": "%CD%\.venv\Scripts\python.exe",
echo      "args": ["%CD%\server.py"],
echo      "env": {
echo        "GEMINI_API_KEY": "?ш린??API???낅젰"
echo      }
echo    }
echo.
echo 3. Claude Desktop???ъ떆?묓븯?몄슂.
echo ============================================
pause